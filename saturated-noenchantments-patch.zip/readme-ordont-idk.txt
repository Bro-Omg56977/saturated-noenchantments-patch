OFFICIAL DOWNLOAD LINKS

Planet Minecraft: https://www.planetminecraft.com/data-pack/saturated-1-18-2-dimension/ 

modrinth: https://modrinth.com/datapack/saturated

if you didnt get the datapack or mod versions from the links here then you didn't download an official version and you probably have a virus ¯\_(ツ)_/¯

no curseforge versions

_______________________________________________________________________________________________________________________________________________________________________
OTHER LINKS:

the discord server: https://discord.gg/zFCy2sT3zJ

discord username: bro_omg

github with source code and dev versions: https://github.com/Bro-Omg56977/saturated_truedev

youtube channel: https://www.youtube.com/channel/UCHfUM22UfLiTycQ5hHglDeg

_______________________________________________________________________________________________________________________________________________________________________
NOTE ABOUT POTENTIAL COMPATABILITY AND/OR INCOMPATABILITIES:

while there should be little to no incompatabilities for basically anything as far as i can tell, there's a few exceptions that apply to generally anything

MODS THAT ALTER LOOT: Saturated contains some enchantments that are only supposed to be used by certain enemies and bosses. These enchantments (in the enemy folder) could be potentially accessable to survival players when it usually shouldn't be in any circumstance

MODS THAT ALTER OVERWORLD NOISE: i forgot the specific file name, but the saturated dimension uses overworld noises to generate, like temperture, erosion, depth, etc. if a different mod modifies those values, then it will probably also chance how saturated generates

MODS THAT USE THE TEAMS COMMAND: saturated adds certain mobs to teams, and some functions cause players to join or leave teams.

(only sometimes break thinks) MODS THAT USE TAGS OR SCOREBOARDS: Saturated uses alot of scoreboards and tags. like 40+ i think. unfortunatly i didnt have the foresight to label then beforehand (like sat.soul_count instead of just soul_count) so that may cause some weird interactions


_______________________________________________________________________________________________________________________________________________________________________
NOTES ABOUT COPYRIGHT:

Not really sure what to put here. do not redistribute. some in the discord asked about copyright so i guess ill put my answwers to those questions and more in in this section

Yes, you can make youtube videos about saturated, actually i kinda implore you to, as the only videos about saturated that i know of are ones that i have made myself. although do keep in mind that saturated is still not finished... actually, im not sure if i will ever "finsh" saturated

yes, you can include saturated in your server. wether it be private, public, or otherwise

yes, you can include saturated in modpacks if you want, wether it be for personal use, private, unlisted, public, or otherwise

yes, you can modify saturated in any way, including backports, as long as it's for personal use... and servrs, i guess. and modpacks, but im not sure how that would work

yes, you can create, like, an addon/expansion to saturated. im... not exactly sure how that would work, but a couple of people have asked if they could in the past, and yeah i guess you can do that idk

no, plz don't ever redistribute saturated publicly. this includes uploading saturated to a modding platform, uploading saturated to your own website, uploading a unoffical version / modded version, uploading a backport of saturated, etc.

there's probably a few others i forgot to mention but ill probably add it in the future
_______________________________________________________________________________________________________________________________________________________________________
INSPIRATIONS AND CREDITS:

-_humanoid lets me use altered versions their wubflies, lushrooms, and pumpkins
-WilliamWythers lets me use a modified version of their coral discs, and their Phantasmal Forest add-on is a huge inspiration to the enchanted forest
-attempted to re-create some elements from Terralith
-Bracken Pack - I don't remember the biome, but it had floating ice in the air, and i really liked it lol. Also the lamp posts are inspired by the ones in the city biome if i remember correctly
-crystalized peaks heavily inspired by BetterEnd's crystal mountains
-verdant spires heavily inspired by lush stacks from BYG
-Gye20's forge structure looked cool
-ssneaky's superstructures looked cool aswell
-Denizen helped me out with some teleporting code
-PMC user Xfulminex, i looked at his enchantment code to figure out how to do it
-PMC user Ercerus, some parts of the skeletown are heavily inspired by his illager fortresses
-discord user Latte gave me a couple of ideas i may or may not use in the future
-Nova and Whity from nova structures, they let me use their cartographer code
-Ercerus, i got inspired by their building style from their illager fortresses
-Sunken city from cataclysm
-Sluda builds' futuristic city building